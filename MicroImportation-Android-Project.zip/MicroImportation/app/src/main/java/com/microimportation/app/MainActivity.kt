package com.microimportation.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = AppState(applicationContext)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF0B6E8A))) {
                App(st)
            }
        }
    }
}

@Composable
fun App(st: AppState) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🚚" to "Shipments", "✈️" to "Trips", "📦" to "Products", "📊" to "Cost", "👥" to "Suppliers")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, p ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i },
                    icon = { Text(p.first) },
                    label = { Text(p.second, fontSize = 11.sp, maxLines = 1) }
                )
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).statusBarsPadding()) {
            when (tab) {
                0 -> ShipmentsScreen(st)
                1 -> TripsScreen(st) { id -> st.selTrip = id; tab = 0 }
                2 -> ProductsScreen(st)
                3 -> CostScreen(st)
                else -> SuppliersScreen(st)
            }
        }
    }
}
