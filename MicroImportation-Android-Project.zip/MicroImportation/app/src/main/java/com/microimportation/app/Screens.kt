package com.microimportation.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

/* ---------- shared pieces ---------- */

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun TxtField(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true, modifier = modifier)
}

@Composable
fun NumField(
    label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(),
    placeholder: String? = null, onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        placeholder = if (placeholder != null) ({ Text(placeholder) }) else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
fun KV(k: String, v: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, Modifier.weight(1f), fontSize = 13.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(v, fontSize = 13.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
fun Confirm(text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        confirmButton = { TextButton(onClick = onYes) { Text("Delete") } },
        dismissButton = { TextButton(onClick = onNo) { Text("Cancel") } },
        text = { Text(text) }
    )
}

@Composable
fun Cell(t: String, w: Int, bold: Boolean = false, bg: Color = Color.Transparent) {
    Text(
        t,
        Modifier.width(w.dp).background(bg).border(0.5.dp, Color.Gray).padding(6.dp),
        fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
    )
}

/* ---------- Trips ---------- */

private fun blankTrip() = Trip(0, "", LocalDate.now().toString(), "", "", "", "", "", "", "", "", "", "", "", "w")

@Composable
fun TripsScreen(st: AppState, openShip: (Long) -> Unit) {
    var form by remember { mutableStateOf(blankTrip()) }
    var editId by remember { mutableStateOf<Long?>(null) }
    var msg by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<Long?>(null) }

    Page {
        Panel {
            Text(if (editId == null) "New trip" else "Edit trip", fontWeight = FontWeight.Bold)
            TxtField("Trip name or destination", form.name) { form = form.copy(name = it) }
            TxtField("Date (yyyy-mm-dd)", form.date) { form = form.copy(date = it) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("Ticket (local)", form.ticket, Modifier.weight(1f)) { form = form.copy(ticket = it) }
                NumField("Hotel (local)", form.hotel, Modifier.weight(1f)) { form = form.copy(hotel = it) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("Travel expenses (local)", form.exp, Modifier.weight(1f)) { form = form.copy(exp = it) }
                NumField("Visa fees (local)", form.visa, Modifier.weight(1f)) { form = form.copy(visa = it) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("Weight allowance (kg)", form.w, Modifier.weight(1f)) { form = form.copy(w = it) }
                NumField("Extra weight (kg)", form.xw, Modifier.weight(1f)) { form = form.copy(xw = it) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("Extra weight cost (local)", form.xc, Modifier.weight(1f)) { form = form.copy(xc = it) }
                NumField("Black market rate", form.bm, Modifier.weight(1f)) { form = form.copy(bm = it) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("Bank rate", form.bk, Modifier.weight(1f)) { form = form.copy(bk = it) }
                NumField("Visa card commission %", form.vc, Modifier.weight(1f)) { form = form.copy(vc = it) }
            }
            NumField("Customs % (of value at bank rate)", form.cust) { form = form.copy(cust = it) }
            Text("Card purchases: value at the black market rate, plus the commission at the bank rate.", fontSize = 12.sp)
            KV("Total weight allowed", fmt(form.w.num() + form.xw.num()) + " kg")
            KV("Total expenses", fmt(tripTotal(form)), true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    if (form.name.isBlank()) {
                        msg = "Enter a trip name first."
                    } else if (form.bm.num() <= 0 || form.bk.num() <= 0) {
                        msg = "Enter the black market rate and the bank rate."
                    } else {
                        val e = editId
                        if (e != null) {
                            val i = st.trips.indexOfFirst { t -> t.id == e }
                            if (i >= 0) {
                                val old = st.trips[i]
                                st.trips[i] = form.copy(id = e, items = old.items, alloc = old.alloc)
                            }
                        } else {
                            val id = System.currentTimeMillis()
                            st.trips.add(0, form.copy(id = id))
                            st.selTrip = id
                        }
                        st.save()
                        form = blankTrip()
                        editId = null
                        msg = "Trip saved."
                    }
                }) { Text(if (editId == null) "Save trip" else "Update trip") }
                if (editId != null) {
                    OutlinedButton(onClick = { form = blankTrip(); editId = null; msg = "" }) { Text("Cancel") }
                }
            }
            if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp)
        }

        Text("Saved trips", fontWeight = FontWeight.Bold)
        if (st.trips.isEmpty()) Text("No saved trips yet.", fontSize = 13.sp)
        st.trips.forEach { t ->
            val c = compute(t, t.items, t.alloc)
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(t.name, fontWeight = FontWeight.Bold)
                    Text(t.date, fontSize = 13.sp)
                }
                KV("Total expenses", fmt(tripTotal(t)))
                KV("Total weight", fmt(t.w.num() + t.xw.num()) + " kg")
                KV("Black market / Bank / Visa / Customs", fmt(t.bm.num()) + " / " + fmt(t.bk.num()) + " / " + fmt(t.vc.num()) + "% / " + fmt(t.cust.num()) + "%")
                KV("Shipment", if (t.items.isEmpty()) "none yet" else t.items.size.toString() + " items saved")
                KV("Total with shipment", fmt(if (t.items.isEmpty()) tripTotal(t) else c.totals.all), true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { openShip(t.id) }) { Text("Shipment") }
                    OutlinedButton(onClick = { form = t.copy(items = emptyList()); editId = t.id; msg = "" }) { Text("Edit") }
                    TextButton(onClick = { del = t.id }) { Text("Delete") }
                }
            }
        }
    }

    del?.let { id ->
        Confirm("Delete this trip and its shipment?", {
            st.trips.removeAll { it.id == id }
            st.save()
            del = null
        }, { del = null })
    }
}

/* ---------- Shipments ---------- */

@Composable
fun ShipmentsScreen(st: AppState) {
    if (st.trips.isEmpty()) {
        Page { Text("No trips yet. Save a trip on the Trips tab first.") }
        return
    }
    val trip = st.trips.firstOrNull { it.id == st.selTrip } ?: st.trips.first()
    var draft by remember(trip.id, trip.items) { mutableStateOf(trip.items) }
    var alloc by remember(trip.id) { mutableStateOf(trip.alloc) }
    var dirty by remember(trip.id) { mutableStateOf(false) }
    var msg by remember(trip.id) { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val c = compute(trip, draft, alloc)

    fun upd(i: Int, f: (Item) -> Item) {
        draft = draft.mapIndexed { j, x -> if (j == i) f(x) else x }
        dirty = true
    }

    Page {
        Panel {
            Box {
                OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(trip.name + "  " + trip.date)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    st.trips.forEach { t ->
                        DropdownMenuItem(text = { Text(t.name + "  " + t.date) }, onClick = { st.selTrip = t.id; menu = false })
                    }
                }
            }
            Text("Spread trip expenses by", fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (alloc != "v") Button(onClick = {}) { Text("Weight") }
                else OutlinedButton(onClick = { alloc = "w"; dirty = true }) { Text("Weight") }
                if (alloc == "v") Button(onClick = {}) { Text("Value") }
                else OutlinedButton(onClick = { alloc = "v"; dirty = true }) { Text("Value") }
            }
            KV("Customs rate", fmt(trip.cust.num()) + "%")
            KV("Total weight", fmt(c.totals.total) + " kg")
            KV("Weight used", fmt(c.totals.used) + " kg")
            KV("Weight remaining", fmt(c.totals.rem) + " kg", true)
        }

        draft.forEachIndexed { i, item ->
            val ln = c.lines[i]
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Item " + (i + 1), fontWeight = FontWeight.Bold)
                    TextButton(onClick = { draft = draft.filterIndexed { j, _ -> j != i }; dirty = true }) { Text("Delete") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TxtField("Item name", item.name, Modifier.weight(1.4f)) { v ->
                        upd(i) { x ->
                            val m = st.products.firstOrNull { p -> p.name.equals(v.trim(), true) }
                            x.copy(name = v, hs = m?.hs ?: x.hs)
                        }
                    }
                    TxtField("HS code", item.hs, Modifier.weight(1f)) { v -> upd(i) { x -> x.copy(hs = v) } }
                }
                val key = item.name.trim()
                if (key.isNotEmpty() && st.products.none { p -> p.name.equals(key, true) }) {
                    st.products.filter { p -> p.name.contains(key, true) }.take(4).forEach { p ->
                        TextButton(onClick = { upd(i) { x -> x.copy(name = p.name, hs = p.hs) } }) {
                            Text(p.name + "  (HS " + p.hs + ")")
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Unit weight (kg)", item.w, Modifier.weight(1f)) { v -> upd(i) { x -> x.copy(w = v) } }
                    NumField("Unit price (foreign)", item.p, Modifier.weight(1f)) { v -> upd(i) { x -> x.copy(p = v) } }
                }
                NumField("Quantity", if (item.qa) "" else item.q, placeholder = "Auto: " + ln.q.toInt()) { v ->
                    upd(i) { x -> if (v.isBlank()) x.copy(qa = true, q = "") else x.copy(qa = false, q = v) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Payment")
                    if (item.pay == "cash") Button(onClick = {}) { Text("Cash") }
                    else OutlinedButton(onClick = { upd(i) { x -> x.copy(pay = "cash") } }) { Text("Cash") }
                    if (item.pay == "card") Button(onClick = {}) { Text("Card") }
                    else OutlinedButton(onClick = { upd(i) { x -> x.copy(pay = "card") } }) { Text("Card") }
                }
                KV("Max quantity from remaining weight", ln.mx?.toString() ?: "-")
                KV("Value (foreign)", fmt(ln.v))
                KV("Purchase cost", fmt(ln.buy))
                KV("Customs", fmt(ln.cus))
                KV("Expenses share", fmt(ln.share))
                KV("Item total", fmt(ln.tot))
                KV("Cost per piece", fmt(ln.pc), true)
            }
        }

        OutlinedButton(onClick = { draft = draft + Item(); dirty = true }, modifier = Modifier.fillMaxWidth()) { Text("Add item") }

        Panel {
            Text("Shipment summary", fontWeight = FontWeight.Bold)
            KV("Goods value (foreign)", fmt(c.totals.v))
            KV("Purchase cost (local)", fmt(c.totals.buy))
            KV("Total customs", fmt(c.totals.cus))
            KV("Trip expenses", fmt(c.totals.exp))
            KV("Grand total", fmt(c.totals.all), true)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val idx = st.trips.indexOfFirst { t -> t.id == trip.id }
                if (idx >= 0) st.trips[idx] = trip.copy(items = draft, alloc = alloc)
                var added = 0
                draft.forEach { x ->
                    val nm = x.name.trim()
                    if (nm.isNotEmpty() && x.hs.isNotBlank() && st.products.none { p -> p.name.equals(nm, true) }) {
                        st.products.add(Product(System.currentTimeMillis() + added, nm, x.hs.trim()))
                        added++
                    }
                }
                st.save()
                dirty = false
                msg = "Shipment saved." + (if (added > 0) " " + added + " new product(s) added to Products." else "")
            }) { Text("Save shipment") }
            OutlinedButton(onClick = { draft = trip.items; alloc = trip.alloc; dirty = false; msg = "" }) { Text("Discard changes") }
        }
        Text(
            if (dirty) "Unsaved changes. Tap Save shipment before leaving this tab."
            else if (msg.isNotEmpty()) msg
            else if (trip.items.isNotEmpty()) "Shipment saved. You can keep editing and save again."
            else "Not saved yet.",
            fontSize = 13.sp
        )
    }
}

/* ---------- Products ---------- */

@Composable
fun ProductsScreen(st: AppState) {
    var pn by remember { mutableStateOf("") }
    var ph by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<Long?>(null) }

    Page {
        Panel {
            Text("Add product", fontWeight = FontWeight.Bold)
            TxtField("Product name", pn) { pn = it }
            TxtField("HS code", ph) { ph = it }
            Button(onClick = {
                val nm = pn.trim()
                if (nm.isEmpty() || ph.isBlank()) {
                    msg = "Enter both the product name and the HS code."
                } else if (st.products.any { p -> p.name.equals(nm, true) }) {
                    msg = "This product already exists."
                } else {
                    st.products.add(0, Product(System.currentTimeMillis(), nm, ph.trim()))
                    st.save()
                    pn = ""; ph = ""; msg = "Product added."
                }
            }) { Text("Add product") }
            if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp)
        }
        TxtField("Search by name or HS code", q) { q = it }
        val list = st.products.filter { p -> q.isBlank() || p.name.contains(q.trim(), true) || p.hs.contains(q.trim()) }
        if (list.isEmpty()) Text("No products found.", fontSize = 13.sp)
        list.forEach { p ->
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text("HS code: " + p.hs, fontSize = 13.sp)
                    }
                    TextButton(onClick = { del = p.id }) { Text("Delete") }
                }
            }
        }
    }
    del?.let { id ->
        Confirm("Delete this product?", {
            st.products.removeAll { it.id == id }
            st.save()
            del = null
        }, { del = null })
    }
}

/* ---------- Cost table ---------- */

@Composable
fun CostScreen(st: AppState) {
    val withItems = st.trips.filter { it.items.isNotEmpty() }
    val head = Color(0x220B6E8A)
    val tot = Color(0x33FFC107)
    Page {
        if (withItems.isEmpty()) Text("No saved shipments yet. Save a shipment on the Shipments tab and it will appear here.")
        withItems.forEach { t ->
            val c = compute(t, t.items, t.alloc)
            Text(t.name + "  " + t.date, fontWeight = FontWeight.Bold)
            Column(Modifier.horizontalScroll(rememberScrollState())) {
                Row {
                    Cell("Item", 130, true, head); Cell("HS code", 90, true, head); Cell("Qty", 55, true, head)
                    Cell("Pay", 60, true, head); Cell("Value before", 100, true, head); Cell("Purchase cost", 105, true, head)
                    Cell("Customs", 90, true, head); Cell("Expenses share", 110, true, head)
                    Cell("Total cost", 105, true, head); Cell("Cost per piece", 105, true, head)
                }
                t.items.forEachIndexed { i, x ->
                    val l = c.lines[i]
                    Row {
                        Cell(x.name.ifBlank { "Item " + (i + 1) }, 130); Cell(x.hs, 90); Cell(fmt(l.q), 55)
                        Cell(if (x.pay == "card") "Card" else "Cash", 60); Cell(fmt(l.v), 100); Cell(fmt(l.buy), 105)
                        Cell(fmt(l.cus), 90); Cell(fmt(l.share), 110); Cell(fmt(l.tot), 105); Cell(fmt(l.pc), 105, true)
                    }
                }
                Row {
                    Cell("Trip total", 130, true, tot); Cell("", 90, false, tot); Cell("", 55, false, tot); Cell("", 60, false, tot)
                    Cell(fmt(c.totals.v), 100, true, tot); Cell(fmt(c.totals.buy), 105, true, tot)
                    Cell(fmt(c.totals.cus), 90, true, tot); Cell(fmt(c.totals.exp), 110, true, tot)
                    Cell(fmt(c.totals.all), 105, true, tot); Cell("", 105, false, tot)
                }
            }
        }
    }
}

/* ---------- Suppliers ---------- */

@Composable
fun SuppliersScreen(st: AppState) {
    var n by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("") }
    var ph by remember { mutableStateOf("") }
    var em by remember { mutableStateOf("") }
    var web by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<Long?>(null) }
    val uri = LocalUriHandler.current

    Page {
        Panel {
            Text("Add supplier", fontWeight = FontWeight.Bold)
            TxtField("Name", n) { n = it }
            TxtField("Field of business", f) { f = it }
            TxtField("Phone", ph) { ph = it }
            TxtField("Email", em) { em = it }
            TxtField("Website", web) { web = it }
            Button(onClick = {
                if (n.isBlank()) {
                    msg = "Enter the supplier name."
                } else {
                    st.suppliers.add(0, Supplier(System.currentTimeMillis(), n.trim(), f.trim(), ph.trim(), em.trim(), web.trim()))
                    st.save()
                    n = ""; f = ""; ph = ""; em = ""; web = ""; msg = "Supplier added."
                }
            }) { Text("Add supplier") }
            if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp)
        }
        if (st.suppliers.isEmpty()) Text("No suppliers yet.", fontSize = 13.sp)
        st.suppliers.forEach { s ->
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(s.name, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { del = s.id }) { Text("Delete") }
                }
                KV("Field of business", s.field.ifBlank { "-" })
                KV("Phone", s.phone.ifBlank { "-" })
                KV("Email", s.email.ifBlank { "-" })
                KV("Website", s.web.ifBlank { "-" })
                if (s.web.isNotBlank()) {
                    TextButton(onClick = {
                        try {
                            uri.openUri(if (s.web.startsWith("http", true)) s.web else "https://" + s.web)
                        } catch (e: Exception) { }
                    }) { Text("Open website") }
                }
            }
        }
    }
    del?.let { id ->
        Confirm("Delete this supplier?", {
            st.suppliers.removeAll { it.id == id }
            st.save()
            del = null
        }, { del = null })
    }
}
