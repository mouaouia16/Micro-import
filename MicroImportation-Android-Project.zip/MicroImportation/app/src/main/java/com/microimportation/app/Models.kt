package com.microimportation.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

data class Item(
    val name: String = "", val hs: String = "", val w: String = "", val p: String = "",
    val q: String = "", val qa: Boolean = true, val pay: String = "cash"
)

data class Trip(
    val id: Long, val name: String, val date: String, val ticket: String, val hotel: String,
    val exp: String, val visa: String, val xc: String, val w: String, val xw: String,
    val bm: String, val bk: String, val vc: String, val cust: String,
    val alloc: String = "w", val items: List<Item> = emptyList()
)

data class Product(val id: Long, val name: String, val hs: String)
data class Supplier(val id: Long, val name: String, val field: String, val phone: String, val email: String, val web: String)

fun String.num(): Double = trim().replace(',', '.').toDoubleOrNull() ?: 0.0
fun fmt(v: Double): String =
    if (v.isFinite()) DecimalFormat("#,##0.##", DecimalFormatSymbols(Locale.US)).format(v) else "0"

fun tripTotal(t: Trip): Double = t.ticket.num() + t.hotel.num() + t.exp.num() + t.visa.num() + t.xc.num()

private class Tmp(val mx: Int?, val q: Double, val used: Double, val v: Double, val buy: Double, val cus: Double)

data class Line(
    val mx: Int?, val q: Double, val used: Double, val v: Double, val buy: Double,
    val cus: Double, val share: Double, val tot: Double, val pc: Double
)

data class Totals(
    val v: Double, val buy: Double, val cus: Double, val exp: Double,
    val used: Double, val total: Double, val rem: Double, val all: Double
)

data class Calc(val lines: List<Line>, val totals: Totals)

/** Card = value x black market rate + commission at the bank rate. Customs = value x bank rate x customs %. */
fun compute(t: Trip, items: List<Item>, alloc: String): Calc {
    var rem = t.w.num() + t.xw.num()
    val total = rem
    val bm = t.bm.num()
    val bk = t.bk.num()
    val vc = t.vc.num()
    val cu = t.cust.num()
    val tmp = items.map { item ->
        val w = item.w.num()
        val mx = if (w > 0) Math.max(0.0, Math.floor(rem / w + 1e-9)).toInt() else null
        val q = if (item.qa) (mx?.toDouble() ?: 0.0) else item.q.num()
        val used = q * w
        rem -= used
        val v = q * item.p.num()
        val buy = v * bm + (if (item.pay == "card") v * vc / 100 * bk else 0.0)
        Tmp(mx, q, used, v, buy, v * bk * cu / 100)
    }
    val sw = tmp.sumOf { it.used }
    val sv = tmp.sumOf { it.v }
    val exp = tripTotal(t)
    val byW = alloc != "v" && sw > 0
    val lines = tmp.map { x ->
        val share = if (byW) exp * x.used / sw else if (sv > 0) exp * x.v / sv else 0.0
        val tot = x.buy + x.cus + share
        Line(x.mx, x.q, x.used, x.v, x.buy, x.cus, share, tot, if (x.q > 0) tot / x.q else 0.0)
    }
    val buy = tmp.sumOf { it.buy }
    val cus = tmp.sumOf { it.cus }
    val all = buy + cus + (if (lines.isNotEmpty()) exp else 0.0)
    return Calc(lines, Totals(sv, buy, cus, exp, sw, total, total - sw, all))
}

private fun Item.js() = JSONObject().put("name", name).put("hs", hs).put("w", w).put("p", p)
    .put("q", q).put("qa", qa).put("pay", pay)

private fun JSONObject.item() = Item(
    optString("name"), optString("hs"), optString("w"), optString("p"),
    optString("q"), optBoolean("qa", true), optString("pay", "cash")
)

private fun Trip.js() = JSONObject().put("id", id).put("name", name).put("date", date)
    .put("ticket", ticket).put("hotel", hotel).put("exp", exp).put("visa", visa).put("xc", xc)
    .put("w", w).put("xw", xw).put("bm", bm).put("bk", bk).put("vc", vc).put("cust", cust)
    .put("alloc", alloc).put("items", JSONArray(items.map { it.js() }))

private fun JSONObject.trip(): Trip {
    val a = optJSONArray("items") ?: JSONArray()
    return Trip(
        optLong("id"), optString("name"), optString("date"), optString("ticket"), optString("hotel"),
        optString("exp"), optString("visa"), optString("xc"), optString("w"), optString("xw"),
        optString("bm"), optString("bk"), optString("vc"), optString("cust"),
        optString("alloc", "w"), (0 until a.length()).map { a.getJSONObject(it).item() }
    )
}

/** All data lives on the phone (SharedPreferences). No internet is used. */
class AppState(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("micro_importation", Context.MODE_PRIVATE)
    val trips = mutableStateListOf<Trip>()
    val products = mutableStateListOf<Product>()
    val suppliers = mutableStateListOf<Supplier>()
    var selTrip by mutableStateOf<Long?>(null)

    init {
        try { load() } catch (e: Exception) { }
    }

    fun save() {
        val o = JSONObject()
        o.put("trips", JSONArray(trips.map { it.js() }))
        o.put("products", JSONArray(products.map { JSONObject().put("id", it.id).put("name", it.name).put("hs", it.hs) }))
        o.put("suppliers", JSONArray(suppliers.map {
            JSONObject().put("id", it.id).put("name", it.name).put("field", it.field)
                .put("phone", it.phone).put("email", it.email).put("web", it.web)
        }))
        prefs.edit().putString("data", o.toString()).apply()
    }

    private fun load() {
        val s = prefs.getString("data", null) ?: return
        val o = JSONObject(s)
        o.optJSONArray("trips")?.let { a -> for (i in 0 until a.length()) trips.add(a.getJSONObject(i).trip()) }
        o.optJSONArray("products")?.let { a ->
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                products.add(Product(j.optLong("id"), j.optString("name"), j.optString("hs")))
            }
        }
        o.optJSONArray("suppliers")?.let { a ->
            for (i in 0 until a.length()) {
                val j = a.getJSONObject(i)
                suppliers.add(Supplier(j.optLong("id"), j.optString("name"), j.optString("field"), j.optString("phone"), j.optString("email"), j.optString("web")))
            }
        }
    }
}
