@echo off
cd /d "%~dp0"
where python >nul 2>nul || (echo Python is not installed. Use Start-Windows.bat instead. & pause & exit /b)
start "" http://localhost:8080
python -m http.server 8080
